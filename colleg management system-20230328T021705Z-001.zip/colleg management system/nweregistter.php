<form method="post" action ="register.php" id="contact-form">

<input type="text" name="name" placeholder="name"  required />

<textarea id = "address" name="address" placeholder="address"  required /></textarea>


<input type="email" name="email"  placeholder="email" required />


<input type="mobile" name="mobile"  placeholder="mobile" required />


<input type="highest_degree" name="highest_degree"  placeholder="highest degree" required />

<textarea id = "relavant_exp" name="relavant_exp"  placeholder="relavant experience" required /></textarea>

<div class="btn-group" role="group">
<input type="submit" class="btn btn-default" name="btn-signup" value="Enter the box" style="margin-top: 15px; margin-right: 15px; border-radius: 4px;">
 <a href="index.html"><button type="button" class="btn btn-default" style="margin-top: 15px;">&laquo; Back</button></a>
  </div>
