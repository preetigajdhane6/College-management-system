<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="UTF-8">
<title>Register</title>
<link rel="stylesheet" type="text/css" href="login.css">
</head>


<body>

<h3>Register</h3>

<style>
h3 {
    text-align:center;    
	font-size:50px;
    padding:7px;
    color:white;	
	   
	   
	   }




body{
background-image:url("reg.JPG");
background-attachment:fixed;
background-size:cover;
repeat:no-repeat;
}
input{
padding:5px;
}



</style>

<form  align="center" action="db.php " method="post">

<input type="text"name="Member type" placeholder="Member type"><br>
<!--<label for="Member type"></label>
<select id="cars" name="Member type">
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="fiat">Fiat</option>
  <option value="audi">Audi</option>
</select>-->



<input type="text" name="name" placeholder="name"  required /><br>


<input type="email" name="email"  placeholder="email" required /><br>
<input type="mobile" name="mobile"  placeholder="mobile" required /><br>


<input type="text" name="Branch" placeholder=" Branch " required /><br>


<input type="submit"name="submit" value="Submit"><br>


</form>
</body>
</html>
